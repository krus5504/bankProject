package com.bank.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.bank.GenrateReport;
import com.bank.ObjectModel.Transfer;
import com.bank.controller.MainController;
import com.bank.model.Customer;
import com.bank.model.EmployeeLogin;
import com.bank.model.Statements;
import com.bank.repo.CustomerRepo;

@Service
public class CustomerService<R> {

	@Autowired
	CustomerRepo cusRepo;
	
	@Autowired
	StatementsServ stmtService;

	static String gen_Date = null;
	static String gen_tnxId = null;

	
     
	 // this method is used to Find the customer
	  // by using mobile NO
	  // if mobile is Register then its return customer
	  // otherWiss is return null value
	
	public Customer findByMobileNo(Long mobileNo) {

		return cusRepo.findByMobileNo(mobileNo);
	}

	public Customer findByAdharNo(Long adharNo) {

		return cusRepo.findByAdharId(adharNo);
	}

	public Customer save(Customer customer) {

		return cusRepo.save(customer);
	}
	public Customer update(Customer customer) {
		
		return cusRepo.saveAndFlush(customer);
	}
	
	public Customer findById(Integer id) {

		return cusRepo.findById(id).get();
	}

	public Customer findByAccountNo(Long accountNo) {

		return cusRepo.findByAccountNo(accountNo);
	}

	public static String gen_Date() {

		LocalDateTime myDateObj = LocalDateTime.now();
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

		return myDateObj.format(myFormatObj);

	}

	public static String gen_tnxId() {
		Random r = new Random();
		Integer i = r.nextInt();
		String s = new String("tnx " + i);

		return s;

	}

	public ModelAndView fundTransfer(Transfer tns) {

		try {
			EmployeeLogin emp1 = MainController.emp1;
               if(emp1==null) {
            	   return new ModelAndView("redirect:/v1/bank/app");
               }
			Customer b_customer = cusRepo.findByAccountNo(tns.getB_accNo());
			if (b_customer != null && b_customer.getAccountNo() != emp1.getAccNo()) {

				System.out.println("inside if");

				Customer self = cusRepo.findByAccountNo(emp1.getAccNo());
				Double self_bal = self.getBallence();

				if (tns.getAmount() < self_bal) {

					double bal = b_customer.getBallence();
					self_bal = self_bal - tns.getAmount();

					bal = bal + tns.getAmount();
					b_customer.setBallence(bal);
					cusRepo.save(b_customer);

					self.setBallence(self_bal);
					cusRepo.save(self);

					with_st(tns, self);

					diposit_st(tns, self);

					System.out.println(tns);
					GenrateReport.genTranction(self.getfName(),b_customer.getfName(),tns.getAmount());
					return new ModelAndView("/dashbord/trans_Done");
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("redirect:/v1/bank/dashbord/f_trans");
	}

	public void with_st(Transfer tns, Customer self) {
		Statements st = new Statements();
		gen_Date = gen_Date();
		gen_tnxId = gen_tnxId();

		st.setDate(gen_Date);
		st.setTransId(gen_tnxId);
		st.setDescr(tns.getDesc());
		st.setRef(tns.getB_accNo());
		st.setWithd(tns.getAmount());
		st.setSelfNo(self.getAccountNo());

		stmtService.save(st);

	}

	public void diposit_st(Transfer tns, Customer self) {
		Statements st = new Statements();
		st.setDate(gen_Date);
		st.setTransId(gen_tnxId);
		st.setDescr(tns.getDesc());
		st.setRef(self.getAccountNo());
		st.setDepos(tns.getAmount());
		st.setSelfNo(tns.getB_accNo());

		stmtService.save(st);

	}

	
	public final List<Statements> getAllStatementlist(Long acc) {

		return stmtService.findBySelfNo(acc);
	}
	
	/*
	 * This method is Used to Get All Customer List
	 * 
	 * */
	  public List<Customer> getAllCustomer() {
		  
		  return cusRepo.findAll();		  
	  }

	  /*This method is Used To Find The List OF
	   *  Cusotmer by using First Name And LastName
	   *  
	   * 
	   * */
	  
	  
	public List<Customer> findByName(String name) {
	  
		List<Customer> byfName = cusRepo.findByfName(name);
		List<Customer> lName= cusRepo.findBylName(name);
		byfName.addAll(lName);
		
		
		return new ArrayList<Customer>(new HashSet<>(byfName)) ;
	}
	
	/*this method is Used to Find The List <Customer>
	 * by using The address of customer
	 * 
	 * 
	 * */
	  public List<Customer>findByAddress(String address){
		  
		  return cusRepo.findByAddress(address);
	  }
	 
	  
	 /* This method is used to Get a 
	  *  Minimum Costomer if you want Only First 5 Customer Then it 
	  *  
	  *  return only First Five Costomer list
	  * */
	
	  public List<Customer> limitedCustomer(int limit){
		  List<Customer> all = cusRepo.findAll();
		  List<Customer> limit1 = all.stream().limit(limit).collect(Collectors.toList());
		  return limit1;
	  }
	  
	  /* This method is used to Get a 
		  *  Minimum Costomer if you want next 5 Customer Then it 
		  *  
		  *  return next Five Costomer list
		  * */
		
		  public List<Customer> limitedNextPageCustomer(int limit){
			  List<Customer> all = cusRepo.findAll();
			  List<Customer> limit1= all.stream().skip(5).limit(limit).collect(Collectors.toList());

			  return limit1;
		  }
		  
		  public List<Customer> asdBallence(){
			  List<Customer> findAll = cusRepo.findAll();
			  
			  List<Customer> collect = findAll.stream()
					  .sorted(Comparator.comparingDouble(Customer::getBallence))
					  .collect(Collectors.toList());
			  
			  return collect;
		  }
		  
		  public List<Customer> desBallence(){
			  List<Customer> findAll = cusRepo.findAll();
			  
			  List<Customer> collect = findAll.stream()
					  .sorted(Comparator.comparingDouble(Customer::getBallence).reversed())
					  .collect(Collectors.toList());
			  
			  return collect;
		  }
		  
		  
		  public List<Customer> asdFirstName(){
			   List<Customer> collect = cusRepo.findAll().stream()
					   .sorted(Comparator.comparing(Customer::getfName))
					  .collect(Collectors.toList());
			  
			  return collect;
		  }
		  
		  public List<Customer> lessThanBallence(int bal){
			  
			  
			  
			  return cusRepo.findAll().stream()
			  			.filter(c->c.getBallence() <bal )
			  			.collect(Collectors.toList());
		  }
		  
		  public List<Customer> greterThanBallence(int bal){
			  
			  return cusRepo.findAll().stream()
					  .filter(e->e.getBallence()>bal)
					  .collect(Collectors.toList());
		  }
		  
		  public List<Customer> findCusAtListOneTransaction(){
			  List<Customer> customers = cusRepo.findAll();
			  
			  
			  
			  List<Customer> collect = customers.stream().filter(c-> getAllStatementlist(c.getAccountNo()).size()!=0)
			  .collect(Collectors.toList());
			          
			  
			  return collect;
		  }
		  
		  
		 
	public Map<Long, Integer> countHowManyTransaction() {

		List<Customer> findAll = cusRepo.findAll();

		Map<Long, List<Customer>> collect = findAll.stream()
				.filter(e -> getAllStatementlist(e.getAccountNo()).size() >= 0)
				.collect(Collectors.groupingBy(Customer::getAccountNo));

		Set<Entry<Long, List<Customer>>> entrySet = collect.entrySet();

		Map<Long, Integer> count = new HashMap<>();

		for (Entry<Long, List<Customer>> entry : entrySet) {
			Long key = entry.getKey();
			int count1 = getAllStatementlist(key).size();

			count.put(key, count1);

		}
		return count;
	}
	
	public Map<Long, Map<Long, Double>> totalSumOfPeymentTransForDebit() {
		Map<Long, Integer> transaction = countHowManyTransaction();

		Set<Entry<Long, Integer>> keySet = transaction.entrySet();

		Map<Long, Map<Long, Double>> list1 = new HashMap<>();

		for (Entry<Long, Integer> keys : keySet) {
			Long key = keys.getKey();
			List<Statements> statments = stmtService.findBySelfNo(key);
			Map<Long, Double> list = new HashMap<>();
			double depo = 0;
			long count = 0;
			if (!statments.isEmpty()) {

				for (Statements stmt : statments) {

					try {
						depo = depo + stmt.getDepos();// it is Deposite olny
						count++;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}
			list.put(count, depo);
			list1.put(key, list);
		}

		return list1;
	}
	public Map<Long, Map<Long, Double>> totalSumOfPeymentTransForWithdrol() {
		Map<Long, Integer> transaction = countHowManyTransaction();

		Set<Entry<Long, Integer>> keySet = transaction.entrySet();

		Map<Long, Map<Long, Double>> list1 = new HashMap<>();

		for (Entry<Long, Integer> keys : keySet) {
			Long key = keys.getKey();
			List<Statements> statments = stmtService.findBySelfNo(key);
			Map<Long, Double> list = new HashMap<>();
			double depo = 0;
			long count = 0;
			if (!statments.isEmpty()) {

				for (Statements stmt : statments) {

					try {
						depo = depo + stmt.getWithd();// it is withDrowal olny
						count++;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			list.put(count, depo);
			list1.put(key, list);
		}

		return list1;
	}
	
	
	public Statements highTransaction() {
		
			List<Statements> allStatement = stmtService.getAllStatement();
			 Statements statements = allStatement.stream()
			.filter(e->e.getWithd()!=null)
			.max(Comparator.comparingDouble(Statements::getWithd)).get();
			 
			Map<Long, List<Statements>> collect = allStatement.stream()
			.collect(Collectors.groupingBy(Statements::getRef));
			
			
			return statements;
	}
}


class employee{
	  String firstname;
	  String lastname;
	   int age;
	
	   public employee(String firstname, String lastname, int age) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.age = age;
	}
	  
	   
	   public static void main(String[] args) {
		   
		 List<employee> e1= new ArrayList<>();
		 e1.add(new employee("karan", "kumar", 22));
		 e1.add(new employee("vinayak", "kumar", 22));
		 e1.add(new employee("ViDHi", "kumar", 22));
		 e1.add(new employee("RaNI", "kumar", 22));
		 e1.add(new employee("Pawan", "kumar", 22));
		 
		  e1.stream().map(employee -> employee.firstname.toUpperCase());

		 
		 
		   
	}
	   
	
}

