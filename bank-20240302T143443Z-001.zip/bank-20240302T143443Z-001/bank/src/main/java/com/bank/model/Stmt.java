package com.bank.model;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
public class Stmt {

	
	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
		Integer srNo;
	    private Date date;
		private String transId;
		private String descr;
		private Double amount;
		private Long accNo;
		
		public Integer getSrNo() {
			return srNo;
		}
		public void setSrNo(Integer srNo) {
			this.srNo = srNo;
		}
		public Date getDate() {
			return date;
		}
		public void setDate(Date date) {
			this.date = date;
		}
		public String getTransId() {
			return transId;
		}
		public void setTransId(String transId) {
			this.transId = transId;
		}
		public String getDescr() {
			return descr;
		}
		public void setDescr(String descr) {
			this.descr = descr;
		}
		public Double getAmount() {
			return amount;
		}
		public void setAmount(Double amount) {
			this.amount = amount;
		}
		public Long getAccNo() {
			return accNo;
		}
		public void setAccNo(Long accNo) {
			this.accNo = accNo;
		}
		
		
		@Override
		public String toString() {
			return "Stmt [srNo=" + srNo + ", date=" + date + ", transId=" + transId + ", descr=" + descr + ", amount="
					+ amount + ", accNo=" + accNo + "]";
		}
		
		
		
		
}


