package com.bank.model;

import jakarta.persistence.Entity;

@Entity
public class Debit extends Stmt {

	
	private long debtAcc;
	private double totalBalence;
	
	
	public long getDebtAcc() {
		return debtAcc;
	}
	public void setDebtAcc(long debtAcc) {
		this.debtAcc = debtAcc;
	}
	public double getTotalBalence() {
		return totalBalence;
	}
	public void setTotalBalence(double totalBalence) {
		this.totalBalence = totalBalence;
	}
	
	
	@Override
	public String toString() {
		return "Debit [debtAcc=" + debtAcc + ", totalBalence=" + totalBalence + "]";
	}


	
	
	
}
