package com.bank.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bank.model.Debit;

@Repository
public interface DebitRepo extends JpaRepository<Debit, Integer> {

}
