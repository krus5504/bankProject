package com.bank.ObjectModel;

import java.util.List;

public class DummyList {

	public List<DummyEmployee> emp;

	public List<DummyEmployee> getEmp() {
		return emp;
	}

	public void setEmp(List<DummyEmployee> emp) {
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "DummyList [emp=" + emp + "]";
	}

	public DummyList(List<DummyEmployee> emp) {
		super();
		this.emp = emp;
	}

	public DummyList() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
