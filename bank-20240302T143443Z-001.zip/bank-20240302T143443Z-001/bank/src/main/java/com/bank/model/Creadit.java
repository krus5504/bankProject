package com.bank.model;

import jakarta.persistence.Entity;

@Entity

public class Creadit extends Stmt {

	private long createAcc;
	private double totalBalence;
	
	public long getCreateAcc() {
		return createAcc;
	}
	public void setCreateAcc(long createAcc) {
		this.createAcc = createAcc;
	}
	public double getTotalBalence() {
		return totalBalence;
	}
	public void setTotalBalence(double totalBalence) {
		this.totalBalence = totalBalence;
	}
	
	
	@Override
	public String toString() {
		return "Creadit [createAcc=" + createAcc + ", totalBalence=" + totalBalence + "]";
	}
	
	
	
}
