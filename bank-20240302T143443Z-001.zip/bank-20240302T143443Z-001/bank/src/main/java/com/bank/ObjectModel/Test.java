package com.bank.ObjectModel;



import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import com.bank.repo.DummyEmployeeRepo;






@Service
public class Test {
	@Autowired
	DummyEmployeeRepo dummy;
	 public void GetDummyData() {
		 int  count=1;
		
		RestTemplate rt= new RestTemplate();
		String url="https://api.mockaroo.com/api/ea6b2ab0?count=100&key=29616bf0&MyReq.custom";
		
		
		
		ResponseEntity<List<DummyEmployee>> response = rt.exchange(
		    url,
		    HttpMethod.GET,
		    null,
		    new ParameterizedTypeReference<List<DummyEmployee>>(){});
		List<DummyEmployee> objects = response.getBody();
		
		for (Object object : objects) {
			System.out.println(object);
			
		DummyEmployee dm=	(DummyEmployee)object;
			
			dummy.save(dm);
		}
		
//		for (int i = 0; i < 100; i++) {
//			dm = (DummyEmployee) rt.getForObject(url, DummyEmployee.class);
//			
//			dm.setId(count);
//			System.out.println(dm);
////			dummy.save(dumyList);
//			count++;
//			
//		}
		 		
		 
		 
		
			
		
		
	}

	public static void main(String[] args) {
		System.out.println("main method");
		
		
//		String str="rahul";
//		
//		String[] split = str.split(" ");
//		
//	
//		
//		String message=" preparing to send massage";
//		String subject= "prowings";
//		String to="mayuridaksh05@gmail.com";
//		String from="krushnadaksh555@gmail.com";
//		
//		
//		sentEmail(message, subject, to, from);

	}
	
	
	public static void sentEmail( String massage,String sub,String to,String from) {
		String host="smtp.gmail.com";
		String password="Csp5504@";
		Properties properties = System.getProperties();
		
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", 25);
		properties.put("mail.smtp.ssl.enable", true);
		properties.put("mail.smtp.auth", true);
		
		System.out.println("**************"+properties.toString());
		
		System.out.println("******************");
		Session instance = Session.getInstance(properties, new Authenticator() {
		

			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				// TODO Auto-generated method stub
				return new PasswordAuthentication( "krushnadaksh55@gmail.com","Csp5504@");
			}
		
			
		
		}) ;
		
		
		instance.setDebug(true);
		
		MimeMessage m = new MimeMessage(instance);
		
		try {
			m.setFrom(from);
			
			m.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			
			m.setSubject(sub);
			
			m.setText(massage);
			
			
			Transport.send(m);
			
			System.out.println("Massage sent sucssfully................!");
			
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
