package com.bank;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class GenrateReport {
	static String  paidTo1="";
	static int count=1;
	static File f1=null;
  public static File genTranction() {
	  
	 
	  
	  
	  return null;
			  
  }
  
  
  private  static File createFile(String location ,String name) throws IOException {
	   f1 = new File(location + name+".txt");
	  
	  if(f1.createNewFile()) {
			System.out.println("new file crete");
	  }
		else {
			createFile("Reports/CostTranctionRepo/",paidTo1+count++);
		}
	  
		return f1;
	}
  
  private static File writeFile(File f,String sub) throws IOException {
		if(f.canWrite()) {
			
			FileWriter fw= new FileWriter(f);
//			fw.write(readFile(f), (int)f.length()-1, 15);
			
			fw.write(sub);
			
		
			fw.close();
		}
		return f;
	}
  
	private final static String readFile(File f ,String paidTo, String sender,Double amount) throws IOException {
		
		paidTo1=paidTo;
		Scanner sc= new Scanner(f);
		String s= "";
		String opp=" ";
		
		while(sc.hasNext()) {
//			s= s+" "+sc.next();
			s= sc.nextLine();
			
			if(s.indexOf("Paid_To")!=-1) {
				s=s.substring(0,15) + paidTo;
			}
			if(s.indexOf("Amount")!=-1) {
				s=s.substring(0,15) + amount;
			}
			if(s.indexOf("Debited From")!=-1) {
				s=s.substring(0,19) + sender;
			
			}
			opp=opp+"\n"+s;
		}
		
		File createFile = createFile("Reports/CostTranctionRepo/",paidTo);
		writeFile(createFile,opp);
		return s;
	}


	public static void genTranction(String self, String sender, Double amount) throws IOException {
		File common= new File("Reports/staticTemplate/temp.txt");
		readFile(common,self , sender, amount);
		
	}
  
  
}
