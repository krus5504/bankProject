package com.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bank.ObjectModel.DummyEmployee;
import com.bank.ObjectModel.Test;
import com.bank.model.Customer;
import com.bank.model.Employee;
import com.bank.model.EmployeeLogin;
import com.bank.service.CustomerService;
import com.bank.service.EmployeeService;
import com.bank.service.LoginService;
import com.sun.org.slf4j.internal.Logger;
import com.sun.org.slf4j.internal.LoggerFactory;

import jakarta.persistence.Converter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/v1/bank")
@CrossOrigin
public class MainController {
@Autowired
	EmployeeService es;
@Autowired 
   	LoginService loginSer;
@Autowired
    CustomerService customerServ;
@Autowired
Test t;

		

       public  static EmployeeLogin emp1;
       public  static Employee e1;
       

       @GetMapping("/getDummy")
       
       public String getDummy() {
    	   t.GetDummyData();
    	   System.out.println("Emp++++++++++++++: ");
    	   return "data save";
       }
       
	@GetMapping("/app")
	public ModelAndView main() {
		emp1=null;
	    e1=null;
		return new ModelAndView("index");
	}
	
	@GetMapping("/loginform")
	public ModelAndView login(){
		    return new ModelAndView("login/loginForm");
	}
	@GetMapping("/singUp")
	public ModelAndView singUp(){
		    return new ModelAndView("login/singUpForm");
	}
	@PostMapping("/loginDone")
	public ModelAndView loginDone(@ModelAttribute EmployeeLogin empLogin){
		
		    List<EmployeeLogin> list=loginSer.findByType("customer");
		    
		    for (EmployeeLogin emp : list) {
				if (emp.getUserId().equals(empLogin.getUserId()) && 
						emp.getPassword().equals(empLogin.getPassword())) {
					
				    emp1=emp;
		
					   ModelAndView mv= new ModelAndView("dashbord/dashbord");
					 
					   mv.addObject("fname",emp.getfName());
					   mv.addObject("lname",emp.getlName());
					   
				
					return mv;
				}
			}
		    return new ModelAndView("redirect:/v1/bank/app");
		
	}
	
	
	@GetMapping("/loginDone")
	public ModelAndView dashbord1(){
		if(e1==null) {
			
			 return new ModelAndView("redirect:/v1/bank/app");
		 }			  
		else {
		    return new ModelAndView("dashbord/dashbord");
		}
		
	}
	
	@GetMapping("/empLogin")
	public ModelAndView loginPage() {
		
		 if(e1!=null) {
			 ModelAndView mv = new ModelAndView("dashbord/empDashbord");
			 
			 mv.addObject("ballence", e1.getBallence());
			 return mv ;
		 }
		 else {
			 
			 return new ModelAndView("redirect:/v1/bank/app");
		 }
		
	}


	
	@PostMapping("/empLogin")
	public ModelAndView empLogin(@ModelAttribute EmployeeLogin empLogin){
		   System.out.println("testing........!");
		e1 = es.getByUserId(empLogin.getUserId());
		
		    List<EmployeeLogin> list=loginSer.findByType("Admin");
		    
		    for (EmployeeLogin emp : list) {
				if (emp.getUserId().equals(empLogin.getUserId()) && 
						emp.getPassword().equals(empLogin.getPassword())) {
				            ModelAndView mv= new ModelAndView("dashbord/empDashbord");
				          
				          mv.addObject("ballence", e1.getBallence());
					return mv ;
					
				}
			}
		    return new ModelAndView("redirect:/v1/bank/app");
		
	}
	
	@PostMapping("/saveLoginD")
	public ModelAndView save_loginUser(@ModelAttribute EmployeeLogin emplogin,
			                      HttpServletRequest req,HttpServletResponse res) {
					if(emplogin.getAccNo()==null && emplogin.getPhone()==null) {
								return new ModelAndView("redirect:/v1/bank/app");
				}
				String pwd = (String)req.getParameter("password1");
				Long accNo = emplogin.getAccNo();
				
					if(customerServ.findByAdharNo(accNo)==null) {
							loginSer.checkLogin(emplogin,pwd);
								return new ModelAndView("/login/suc");
				}
		return new ModelAndView("/login/suc");
	}
	
	/*
	 * this method is Used to Create New Account 
	 * Form only ..Display form Olny
	 * for Customer Imformation like Name ,last name, mobile no like that
	 * 
	 * */
	
	@GetMapping("/accForm")
	public ModelAndView createFrom() {
		
		return new ModelAndView("login/accOpenForm");
	}

	
	
	@PostMapping("/accDone")
public ModelAndView accDone(@ModelAttribute Customer customer) {
		
		customer.setAccountNo(0000l);
		Customer cust = customerServ.findByMobileNo(customer.getMobileNo());
		Customer cust1= customerServ.findByAdharNo(customer.getAdharId());
		
		if (cust1==null) {
			try {
						customerServ.save(customer);
						ModelAndView mv= new ModelAndView("login/suc");
						mv.addObject("account", " Account Create sussfully Wait for Aprowal");
				return mv;
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		      return new ModelAndView("redirect:/v1/bank/accForm");
	}
	
	@GetMapping("get/{id}")
	public Employee getEmployeeById(@PathVariable Integer id) {
		
		return es.getEmployeeById(id);
	}
	@GetMapping("/getAll")
	public List<Employee> getAllEmployee() {
		
		return es.getAllEmployee();
	}
	@PostMapping("/save")
	public Employee main(@RequestBody Employee employee) {
		
		
		return es.saveEmployee(employee);
	}
	
	
	@GetMapping("/dashbord")
	public ModelAndView dashbord() {
		
		return new ModelAndView("dashbord/dashbord");
	}
	
	@GetMapping("/popUp")
	public ModelAndView popUp() {
		
		return new ModelAndView("dashbord/popUp");
	}
	
//	--------------------------------------------------------------------------------
//	Tested method
	@PostMapping("/ltest")
	public void  getTest(@RequestParam("acno") String acno,@RequestParam String psw) {
		System.out.println(acno);

		System.out.println(psw);
		
	}
	
	
	
	

}
