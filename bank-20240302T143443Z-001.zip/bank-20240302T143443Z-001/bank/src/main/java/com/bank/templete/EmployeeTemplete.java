package com.bank.templete;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import com.bank.model.Customer;
import com.bank.model.Employee;

public interface EmployeeTemplete {
		
		public ModelAndView allviewsStatement();
		
		public List<Customer> getlimitCustomer(@PathVariable int in);
		
		
}
